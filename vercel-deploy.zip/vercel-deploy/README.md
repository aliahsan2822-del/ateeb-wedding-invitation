# Deploy on Vercel

1. Put every file of this folder at the **root of your repository** (keep the folders `css/`, `js/`, `assets/`).
2. Vercel → Add New → Project → import the repo.
3. Framework Preset: **Other**. Build Command: empty. Output Directory: empty. Root Directory: the folder that contains `index.html`.
4. Deploy, then open the site and hard refresh (Ctrl+F5).

Edit names and the countdown date in `js/config.js`; edit event cards and parents' names in `index.html`.
